import { useParams, Link } from "react-router-dom";
import { posts } from "../data/posts";

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = posts.find((p) => p.slug === slug);

  if (!post) {
    return (
      <div className="bg-white min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-6xl mb-4">😕</p>
          <h1 className="text-2xl font-bold text-gray-900">Post not found</h1>
          <Link to="/blog" className="mt-4 inline-block text-sky-500 hover:underline text-sm">
            ← Back to Blog
          </Link>
        </div>
      </div>
    );
  }

  // Related posts (same category, not the current post)
  const related = posts.filter((p) => p.category === post.category && p.id !== post.id).slice(0, 3);

  return (
    <div className="bg-white min-h-screen">
      {/* Hero */}
      <section className="bg-black border-b border-sky-500/20 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/blog" className="inline-flex items-center gap-2 text-gray-400 hover:text-sky-400 text-sm mb-6 transition-colors duration-200">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16l-4-4m0 0l4-4m-4 4h18" />
            </svg>
            Back to Blog
          </Link>

          <div className="flex items-center gap-3 mb-4">
            <span className="bg-sky-500/10 text-sky-400 text-xs font-semibold px-3 py-1 rounded-full border border-sky-500/20">
              {post.category}
            </span>
            <span className="text-gray-500 text-xs">{post.date}</span>
            <span className="text-gray-500 text-xs">· {post.readTime}</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight">{post.title}</h1>
          <p className="text-gray-400 mt-4 leading-relaxed">{post.excerpt}</p>
          <div className="flex items-center gap-3 mt-6">
            <div className="w-8 h-8 bg-sky-500 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-md shadow-sky-500/30">
              A
            </div>
            <div>
              <p className="text-white text-sm font-semibold">Ayomide Bakare</p>
              <p className="text-gray-500 text-xs">Founder, BakaresChosenProduct</p>
            </div>
          </div>
        </div>
      </section>

      {/* Affiliate Disclosure */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-start gap-3">
          <span className="text-amber-500 mt-0.5 text-sm">⚠️</span>
          <p className="text-amber-800 text-xs leading-relaxed">
            <span className="font-bold">Affiliate Disclosure:</span> This post contains affiliate links. If you purchase through our links, we may earn a small commission at <strong>no extra cost to you</strong>. We only recommend products we genuinely believe in.
          </p>
        </div>
      </div>

      {/* Cover Image */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="rounded-2xl overflow-hidden shadow-xl border border-gray-100">
          <img src={post.coverImage} alt={post.title} className="w-full h-64 sm:h-80 object-cover" />
        </div>
      </div>

      {/* Top Buy Button */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <a
          href={post.affiliateLink}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="flex items-center justify-center gap-3 w-full bg-[#FF9900] hover:bg-[#e68900] text-white font-bold py-4 rounded-2xl shadow-lg shadow-orange-300/30 transition-all duration-200 text-base"
        >
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M13 2.05V2c0-.55-.45-1-1-1s-1 .45-1 1v.05C6.19 2.56 2.56 6.19 2.05 11H2c-.55 0-1 .45-1 1s.45 1 1 1h.05C2.56 17.81 6.19 21.44 11 21.95V22c0 .55.45 1 1 1s1-.45 1-1v-.05c4.81-.51 8.44-4.14 8.95-8.95H22c.55 0 1-.45 1-1s-.45-1-1-1h-.05C21.44 6.19 17.81 2.56 13 2.05z" />
          </svg>
          {post.affiliateButtonText}
        </a>
      </div>

      {/* Article Content */}
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div
          className="prose prose-lg max-w-none
            prose-headings:font-bold prose-headings:text-gray-900
            prose-h2:text-xl prose-h2:mt-8 prose-h2:mb-3 prose-h2:text-sky-700
            prose-p:text-gray-700 prose-p:leading-relaxed prose-p:mb-4
            prose-strong:text-gray-900
          "
          dangerouslySetInnerHTML={{ __html: post.content }}
        />

        {/* Bottom Buy Button */}
        <div className="mt-10">
          <a
            href={post.affiliateLink}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="flex items-center justify-center gap-3 w-full bg-[#FF9900] hover:bg-[#e68900] text-white font-bold py-4 rounded-2xl shadow-lg shadow-orange-300/30 transition-all duration-200 text-base"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M13 2.05V2c0-.55-.45-1-1-1s-1 .45-1 1v.05C6.19 2.56 2.56 6.19 2.05 11H2c-.55 0-1 .45-1 1s.45 1 1 1h.05C2.56 17.81 6.19 21.44 11 21.95V22c0 .55.45 1 1 1s1-.45 1-1v-.05c4.81-.51 8.44-4.14 8.95-8.95H22c.55 0 1-.45 1-1s-.45-1-1-1h-.05C21.44 6.19 17.81 2.56 13 2.05z" />
            </svg>
            {post.affiliateButtonText}
          </a>
        </div>
      </article>

      {/* Recommended Products */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="bg-sky-50 border border-sky-200 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-1 h-6 bg-sky-500 rounded-full" />
            <h2 className="text-xl font-bold text-gray-900">⭐ Recommended Products</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {post.recommendedProducts.map((product) => (
              <a
                key={product.name}
                href={product.affiliateLink}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="group bg-white rounded-xl border border-sky-100 hover:border-sky-400 p-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-all duration-200"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-16 h-16 rounded-lg object-cover border border-gray-100 flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 text-sm leading-tight group-hover:text-sky-600 transition-colors duration-200">
                    {product.name}
                  </h3>
                  <p className="text-sky-600 font-bold text-sm mt-1">{product.price}</p>
                  <span className="inline-block mt-2 bg-[#FF9900] text-white text-xs font-bold px-3 py-1 rounded-full">
                    Buy on Amazon
                  </span>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* All Products */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-1 h-6 bg-gray-800 rounded-full" />
            <h2 className="text-xl font-bold text-gray-900">🛒 All Products Mentioned</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {post.allProducts.map((product) => (
              <a
                key={product.name}
                href={product.affiliateLink}
                target="_blank"
                rel="noopener noreferrer sponsored"
                className="group bg-white rounded-xl border border-gray-100 hover:border-sky-300 p-4 flex flex-col items-center text-center shadow-sm hover:shadow-md transition-all duration-200"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-20 h-20 rounded-lg object-cover border border-gray-100 mb-3"
                />
                <h3 className="font-semibold text-gray-900 text-xs leading-tight group-hover:text-sky-600 transition-colors duration-200 mb-1">
                  {product.name}
                </h3>
                <p className="text-sky-600 font-bold text-sm mb-2">{product.price}</p>
                <span className="bg-[#FF9900] text-white text-xs font-bold px-3 py-1 rounded-full">
                  Buy Now
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Related Posts */}
      {related.length > 0 && (
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-1 h-6 bg-sky-500 rounded-full" />
            <h2 className="text-xl font-bold text-gray-900">Related Reviews</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {related.map((rPost) => (
              <Link
                key={rPost.id}
                to={`/blog/${rPost.slug}`}
                className="group bg-white rounded-xl overflow-hidden border border-gray-100 hover:border-sky-200 shadow-sm hover:shadow-md transition-all duration-200"
              >
                <img
                  src={rPost.coverImage}
                  alt={rPost.title}
                  className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="p-3">
                  <h3 className="text-sm font-semibold text-gray-900 leading-tight group-hover:text-sky-600 transition-colors duration-200 line-clamp-2">
                    {rPost.title}
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">{rPost.date}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
