import { Link } from "react-router-dom";

export default function About() {
  return (
    <div className="bg-white min-h-screen">
      {/* Header */}
      <section className="bg-black border-b border-sky-500/20 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-flex items-center gap-2 bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold px-4 py-1.5 rounded-full mb-5 tracking-wider uppercase">
            👋 About the Reviewer
          </span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
            Meet <span className="text-sky-400">Ayomide Bakare</span>
          </h1>
        </div>
      </section>

      {/* Bio Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row items-center gap-12">
          {/* Avatar */}
          <div className="flex-shrink-0">
            <div className="w-44 h-44 rounded-2xl bg-black border-4 border-sky-500/30 shadow-2xl shadow-sky-500/10 flex items-center justify-center relative">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-sky-500/20 to-transparent pointer-events-none" />
              <div className="w-24 h-24 bg-sky-500 rounded-full flex items-center justify-center text-4xl font-extrabold text-white shadow-lg shadow-sky-500/40">
                A
              </div>
            </div>
            <div className="flex justify-center gap-3 mt-5">
              {/* Social Icons */}
              {[
                {
                  label: "YouTube",
                  icon: (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                    </svg>
                  ),
                },
                {
                  label: "Instagram",
                  icon: (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" />
                    </svg>
                  ),
                },
                {
                  label: "TikTok",
                  icon: (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
                    </svg>
                  ),
                },
                {
                  label: "Pinterest",
                  icon: (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0C5.373 0 0 5.372 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 0 1 .083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z" />
                    </svg>
                  ),
                },
              ].map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  className="w-9 h-9 bg-gray-100 hover:bg-sky-500 text-gray-600 hover:text-white rounded-xl flex items-center justify-center transition-all duration-200"
                >
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Bio text */}
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Hi, I'm Ayomide — and I review products so you don't waste your money.
            </h2>
            <div className="space-y-4 text-gray-600 leading-relaxed text-sm">
              <p>
                I've always been fascinated by technology — from the earliest smartphones to today's AI-powered gadgets. Growing up, I was always the person my friends and family would call before buying a new phone, laptop, or pair of headphones. Eventually, I thought: why not share these insights with the world?
              </p>
              <p>
                <span className="font-semibold text-gray-900">BakaresChosenProduct</span> was born out of that simple idea — a place where people can get genuinely honest, in-depth reviews without worrying about whether the reviewer is just trying to make a sale. I test every product personally, put it through real-world use, and then tell you exactly what I think.
              </p>
              <p>
                While tech is my primary passion, I also cover skincare, home & lifestyle products, and the best deals I can find — because great products span every category.
              </p>
              <p>
                My promise to you: <span className="font-semibold text-gray-900">no fluff, no sponsored opinions, just the truth.</span> If a product isn't worth buying, I'll tell you.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-gray-50 border-y border-gray-100 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900">Why Trust My Reviews?</h2>
            <p className="text-gray-500 text-sm mt-2">My commitment to every reader</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              {
                icon: "🔬",
                title: "Personally Tested",
                desc: "Every product I review has been personally used by me — sometimes for weeks — before I write a single word.",
              },
              {
                icon: "🚫",
                title: "No Sponsored Opinions",
                desc: "Companies don't pay me for positive reviews. My affiliate income comes only after I've already formed my honest opinion.",
              },
              {
                icon: "📊",
                title: "Research-Backed",
                desc: "Beyond personal testing, I dig into specs, compare competitors, and read expert benchmarks to give you a complete picture.",
              },
            ].map((val) => (
              <div key={val.title} className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm text-center hover:shadow-md hover:border-sky-200 transition-all duration-200">
                <div className="text-4xl mb-3">{val.icon}</div>
                <h3 className="font-bold text-gray-900 text-base mb-2">{val.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{val.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-3">Ready to Find Your Next Favourite Product?</h2>
        <p className="text-gray-500 text-sm mb-6 max-w-md mx-auto">
          Browse all my honest reviews and find the right product for you — no second-guessing required.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/blog"
            className="px-8 py-3.5 bg-sky-500 hover:bg-sky-400 text-white font-semibold rounded-xl shadow-lg shadow-sky-500/20 transition-all duration-200 text-sm"
          >
            Browse All Reviews
          </Link>
          <Link
            to="/contact"
            className="px-8 py-3.5 border-2 border-gray-200 hover:border-sky-400 text-gray-700 hover:text-sky-600 font-semibold rounded-xl transition-all duration-200 text-sm"
          >
            Get In Touch
          </Link>
        </div>
      </section>
    </div>
  );
}
