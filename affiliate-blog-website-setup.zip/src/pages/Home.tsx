import { useState } from "react";
import { Link } from "react-router-dom";
import { posts } from "../data/posts";

const categories = ["All", "Tech", "Skincare", "Home & Lifestyle", "Best Deals"];

export default function Home() {
  const [activeCategory, setActiveCategory] = useState("All");

  const featured = posts[0];

  return (
    <div className="bg-white min-h-screen">
      {/* ── Hero ── */}
      <section className="relative bg-black overflow-hidden">
        {/* Background grid */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage:
              "linear-gradient(rgba(14,165,233,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(14,165,233,0.4) 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />
        {/* Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-28 text-center">
          <span className="inline-flex items-center gap-2 bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold px-4 py-1.5 rounded-full mb-6 tracking-wider uppercase">
            <span className="w-1.5 h-1.5 bg-sky-400 rounded-full animate-pulse" />
            Honest Reviews You Can Trust
          </span>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight tracking-tight">
            The Most Trusted
            <span className="block text-sky-400 mt-1">Tech Reviews Online</span>
          </h1>
          <p className="mt-6 text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
            I'm Ayomide Bakare — and I personally test every product before recommending it. No sponsored fluff, no bias. Just the truth about the tech you're thinking about buying.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/blog"
              className="px-8 py-3.5 bg-sky-500 hover:bg-sky-400 text-white font-semibold rounded-xl shadow-lg shadow-sky-500/30 transition-all duration-200 text-sm"
            >
              Browse All Reviews
            </Link>
            <Link
              to="/about"
              className="px-8 py-3.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-semibold rounded-xl transition-all duration-200 text-sm"
            >
              About Ayomide
            </Link>
          </div>
        </div>
      </section>

      {/* ── Stats Bar ── */}
      <section className="bg-black border-y border-sky-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { value: "9+", label: "Reviews Published" },
              { value: "100%", label: "Personally Tested" },
              { value: "4", label: "Categories Covered" },
              { value: "0", label: "Sponsored Posts" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="text-2xl font-extrabold text-sky-400">{stat.value}</p>
                <p className="text-xs text-gray-500 mt-0.5 uppercase tracking-wider">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured Post ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center gap-3 mb-8">
          <span className="w-1 h-6 bg-sky-500 rounded-full" />
          <h2 className="text-2xl font-bold text-gray-900">Featured Review</h2>
        </div>

        <Link to={`/blog/${featured.slug}`} className="group block">
          <div className="rounded-2xl overflow-hidden bg-gray-900 shadow-xl hover:shadow-sky-500/10 transition-all duration-300 border border-gray-800 group-hover:border-sky-500/30 flex flex-col lg:flex-row">
            <div className="lg:w-1/2 overflow-hidden">
              <img
                src={featured.coverImage}
                alt={featured.title}
                className="w-full h-60 lg:h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-sky-500/10 text-sky-400 text-xs font-semibold px-3 py-1 rounded-full border border-sky-500/20">
                  {featured.category}
                </span>
                <span className="text-gray-500 text-xs">{featured.date}</span>
                <span className="text-gray-500 text-xs">· {featured.readTime}</span>
              </div>
              <h3 className="text-2xl lg:text-3xl font-bold text-white leading-tight group-hover:text-sky-400 transition-colors duration-200">
                {featured.title}
              </h3>
              <p className="text-gray-400 mt-4 leading-relaxed text-sm">
                {featured.excerpt}
              </p>
              <div className="mt-6">
                <span className="inline-flex items-center gap-2 text-sky-400 font-semibold text-sm group-hover:gap-3 transition-all duration-200">
                  Read Full Review
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </span>
              </div>
            </div>
          </div>
        </Link>
      </section>

      {/* ── Category Filter ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-4">
        <div className="flex items-center gap-2 flex-wrap">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 border ${
                activeCategory === cat
                  ? "bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20"
                  : "bg-white text-gray-600 border-gray-200 hover:border-sky-400 hover:text-sky-500"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* ── Recent Reviews Grid ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center gap-3 mb-8">
          <span className="w-1 h-6 bg-sky-500 rounded-full" />
          <h2 className="text-2xl font-bold text-gray-900">Latest Reviews</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts
            .filter((p) => activeCategory === "All" || p.category === activeCategory)
            .slice(0, 6)
            .map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
        </div>

        <div className="text-center mt-10">
          <Link
            to="/blog"
            className="inline-flex items-center gap-2 px-8 py-3.5 border-2 border-sky-500 text-sky-500 hover:bg-sky-500 hover:text-white font-semibold rounded-xl transition-all duration-200 text-sm"
          >
            View All Reviews
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </Link>
        </div>
      </section>

      {/* ── Newsletter CTA ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-black rounded-2xl p-10 text-center relative overflow-hidden border border-sky-500/20">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[200px] bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative">
            <span className="text-3xl mb-3 block">📬</span>
            <h2 className="text-2xl font-bold text-white mb-2">Stay in the Loop</h2>
            <p className="text-gray-400 text-sm mb-6 max-w-md mx-auto">
              Get the latest tech reviews, deals, and recommendations delivered straight to your inbox — no spam, ever.
            </p>
            <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 bg-white/5 border border-white/10 focus:border-sky-500 text-white placeholder-gray-500 rounded-xl px-4 py-3 text-sm outline-none transition-colors duration-200"
              />
              <button
                type="submit"
                className="bg-sky-500 hover:bg-sky-400 text-white font-semibold px-6 py-3 rounded-xl text-sm transition-colors duration-200 shadow-lg shadow-sky-500/20"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

function PostCard({ post }: { post: (typeof posts)[0] }) {
  return (
    <Link to={`/blog/${post.slug}`} className="group block">
      <article className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-sky-500/5 hover:border-sky-200 transition-all duration-300 h-full flex flex-col">
        <div className="overflow-hidden h-48">
          <img
            src={post.coverImage}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="p-5 flex flex-col flex-1">
          <div className="flex items-center gap-2 mb-3">
            <span className="bg-sky-50 text-sky-600 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-sky-100">
              {post.category}
            </span>
            <span className="text-gray-400 text-xs">{post.readTime}</span>
          </div>
          <h3 className="font-bold text-gray-900 text-base leading-snug group-hover:text-sky-600 transition-colors duration-200 flex-1">
            {post.title}
          </h3>
          <p className="text-gray-500 text-sm mt-2 line-clamp-2 leading-relaxed">{post.excerpt}</p>
          <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
            <span className="text-xs text-gray-400">{post.date}</span>
            <span className="text-sky-500 text-xs font-semibold group-hover:underline">Read more →</span>
          </div>
        </div>
      </article>
    </Link>
  );
}
