import { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Header */}
      <section className="bg-black border-b border-sky-500/20 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-flex items-center gap-2 bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold px-4 py-1.5 rounded-full mb-5 tracking-wider uppercase">
            📬 Get In Touch
          </span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
            Contact <span className="text-sky-400">Ayomide</span>
          </h1>
          <p className="mt-4 text-gray-400 text-sm max-w-lg mx-auto leading-relaxed">
            Have a question about a product? A suggestion for a future review? Or just want to say hi? I'd love to hear from you.
          </p>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Contact Info */}
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-gray-900 mb-4">Let's Connect</h2>
              <p className="text-gray-500 text-sm leading-relaxed">
                Whether you have a product recommendation, a collaboration inquiry, or just want to chat about tech — my inbox is always open.
              </p>
            </div>

            {/* Email */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-sky-50 border border-sky-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-sky-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-1">Email</p>
                <a
                  href="mailto:AyomideBakare@bakareschosenproduct.com"
                  className="text-sky-600 hover:text-sky-500 text-sm font-medium break-all transition-colors duration-200"
                >
                  AyomideBakare@bakareschosenproduct.com
                </a>
              </div>
            </div>

            {/* Response time */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-sky-50 border border-sky-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-sky-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-1">Response Time</p>
                <p className="text-gray-700 text-sm font-medium">Usually within 24–48 hours</p>
              </div>
            </div>

            {/* Socials */}
            <div>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mb-3">Follow Along</p>
              <div className="flex gap-2 flex-wrap">
                {[
                  { label: "YouTube", icon: "▶" },
                  { label: "Instagram", icon: "📷" },
                  { label: "TikTok", icon: "🎵" },
                  { label: "Pinterest", icon: "📌" },
                ].map((social) => (
                  <a
                    key={social.label}
                    href="#"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-sky-50 hover:text-sky-600 border border-gray-200 hover:border-sky-200 rounded-xl text-xs font-medium text-gray-700 transition-all duration-200"
                  >
                    <span>{social.icon}</span>
                    {social.label}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            {submitted ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center py-16 px-8 bg-sky-50 border border-sky-200 rounded-2xl">
                  <div className="text-5xl mb-4">🎉</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Message Received!</h3>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-sm mx-auto">
                    Thanks for reaching out! I'll get back to you at{" "}
                    <span className="text-sky-600 font-medium">{form.email}</span> within 24–48 hours.
                  </p>
                  <button
                    onClick={() => { setSubmitted(false); setForm({ name: "", email: "", subject: "", message: "" }); }}
                    className="mt-6 px-6 py-2.5 bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold rounded-xl transition-colors duration-200"
                  >
                    Send Another Message
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">
                      Your Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      required
                      placeholder="John Doe"
                      className="w-full border border-gray-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 outline-none transition-all duration-200"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      required
                      placeholder="your@email.com"
                      className="w-full border border-gray-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 outline-none transition-all duration-200"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">
                    Subject <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="subject"
                    value={form.subject}
                    onChange={handleChange}
                    required
                    className="w-full border border-gray-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 rounded-xl px-4 py-3 text-sm text-gray-900 outline-none transition-all duration-200 bg-white"
                  >
                    <option value="">Select a subject...</option>
                    <option value="product-question">Question About a Product</option>
                    <option value="review-request">Request a Product Review</option>
                    <option value="collaboration">Brand Collaboration</option>
                    <option value="affiliate">Affiliate Partnership</option>
                    <option value="general">General Inquiry</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">
                    Message <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    placeholder="Write your message here..."
                    className="w-full border border-gray-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-100 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 outline-none transition-all duration-200 resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-sky-500 hover:bg-sky-400 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-sky-500/20 transition-all duration-200 text-sm flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  Send Message
                </button>
                <p className="text-xs text-gray-400 text-center">
                  Your information is kept private and never shared with third parties.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
