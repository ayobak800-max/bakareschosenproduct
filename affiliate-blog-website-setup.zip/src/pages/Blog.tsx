import { useState } from "react";
import { Link } from "react-router-dom";
import { posts, type Category } from "../data/posts";

const categories: ("All" | Category)[] = ["All", "Tech", "Skincare", "Home & Lifestyle", "Best Deals"];

export default function Blog() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<"All" | Category>("All");

  const filtered = posts.filter((post) => {
    const matchesCategory = activeCategory === "All" || post.category === activeCategory;
    const matchesSearch =
      post.title.toLowerCase().includes(search.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="bg-white min-h-screen">
      {/* Page Header */}
      <section className="bg-black border-b border-sky-500/20 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-flex items-center gap-2 bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-semibold px-4 py-1.5 rounded-full mb-5 tracking-wider uppercase">
            🧠 All Reviews
          </span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
            The <span className="text-sky-400">BakaresChosenProduct</span> Blog
          </h1>
          <p className="mt-4 text-gray-400 max-w-xl mx-auto text-sm leading-relaxed">
            Every post is personally researched and written by Ayomide. Browse by category or search for a specific product.
          </p>

          {/* Search */}
          <div className="mt-8 max-w-lg mx-auto relative">
            <svg
              className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder="Search reviews..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white/5 border border-white/10 focus:border-sky-500 text-white placeholder-gray-500 rounded-xl pl-11 pr-4 py-3 text-sm outline-none transition-colors duration-200"
            />
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="bg-white border-b border-gray-100 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-2 flex-wrap">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 border ${
                  activeCategory === cat
                    ? "bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-500/20"
                    : "bg-white text-gray-600 border-gray-200 hover:border-sky-400 hover:text-sky-500"
                }`}
              >
                {cat}
              </button>
            ))}
            <span className="ml-auto text-xs text-gray-400 font-medium">
              {filtered.length} review{filtered.length !== 1 ? "s" : ""}
            </span>
          </div>
        </div>
      </section>

      {/* Posts Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-5xl mb-4">🔍</p>
            <h3 className="text-xl font-bold text-gray-800">No reviews found</h3>
            <p className="text-gray-500 mt-2 text-sm">Try adjusting your search or category filter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((post) => (
              <Link to={`/blog/${post.slug}`} key={post.id} className="group block">
                <article className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-sky-500/5 hover:border-sky-200 transition-all duration-300 h-full flex flex-col">
                  <div className="overflow-hidden h-48">
                    <img
                      src={post.coverImage}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="bg-sky-50 text-sky-600 text-xs font-semibold px-2.5 py-0.5 rounded-full border border-sky-100">
                        {post.category}
                      </span>
                      <span className="text-gray-400 text-xs">{post.readTime}</span>
                    </div>
                    <h3 className="font-bold text-gray-900 text-base leading-snug group-hover:text-sky-600 transition-colors duration-200 flex-1">
                      {post.title}
                    </h3>
                    <p className="text-gray-500 text-sm mt-2 line-clamp-2 leading-relaxed">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                      <span className="text-xs text-gray-400">{post.date}</span>
                      <span className="text-sky-500 text-xs font-semibold group-hover:underline">Read more →</span>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Affiliate Disclosure */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="bg-sky-50 border border-sky-200 rounded-2xl p-5 flex gap-4 items-start">
          <span className="text-xl mt-0.5">📢</span>
          <p className="text-sky-800 text-sm leading-relaxed">
            <span className="font-bold">Affiliate Disclosure:</span> BakaresChosenProduct participates in the Amazon Associates Program and other affiliate programs. Some links on this blog are affiliate links — if you click and purchase, we may earn a commission at <strong>no extra cost to you</strong>. This never influences our honest opinions.
          </p>
        </div>
      </section>
    </div>
  );
}
